
class Player:
    def __init__(self, Name_of_player):
        self.name = Name_of_player
    def read_position(self):
        while True:
            try:
                inp_cor1 = input("Enter your position (A)",)
                inp_cor2 = input("Enter your position (1)",)
                column = int(inp_cor2)
                if column is not None:
                    return tuple(inp_cor1,column)
            except:
                print('wrong data! Try again!')
player1 = Player('I')
player2 = Player('His')

