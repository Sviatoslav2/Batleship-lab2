import string
import random
import Field
import Player
def generate_field():
    ships_size = [4, 3, 2, 1]
    field = generate_ship(4)
    for count in range(1, len(ships_size)):
        for i in range(count + 1):
            ship = generate_ship(ships_size[count])
            ship_area = make_shp_area(ship)
            while set(ship_area).intersection(set(field)) != set():
                ship = generate_ship(ships_size[count])
                ship_area = make_shp_area(ship)
            field.extend(ship)
    res_field = []
    for i in range(10):
        row = []
        for j in range(10):
            if (i, j) in field:
                row.append('*')
            else:
                row.append(' ')
        res_field.append(row)
    return res_field
def generate_ship(size):
    orientations = ['horizontal', 'vertical']
    orientation = random.choice(orientations)
    row_col = random.randrange(0, 10)
    first_point = random.randrange(0, 10 - size)
    if orientation == 'horizontal':
        ship_coord = [(row_col, i) for i in range(first_point, first_point + size)]
    else:
        ship_coord = [(i, row_col) for i in range(first_point, first_point + size)]
    return ship_coord
def make_shp_area(shp_coords):
    if shp_coords[0][0] - 1 > 0:
        row_start = shp_coords[0][0] - 1
    else :
        row_start = 0
    if shp_coords[-1][0] + 1 < 9 :
        row_end = shp_coords[-1][0] + 1
    else :
        row_end = 9
    if shp_coords[0][1] - 1 > 0:
        col_start = shp_coords[0][1] - 1
    else:
        col_start = 0
    if shp_coords[-1][1] + 1 < 9:
        col_end = shp_coords[-1][1] + 1
    else:
        col_end = 9
    area = []
    for row in range(row_start, row_end + 1):
        for column in range(col_start, col_end + 1):
            area_point = (row, column)
            area.append(area_point)
    return area
lst1 = generate_field()
lst_alfabet = [i for i in string.ascii_uppercase]
def convert_list(lst1):
    str = ''
    for i in lst1:
        for j in i:
            str += j
    tpl = []
    lst = []
    lst_of_grid = []
    for i in lst_alfabet:
        for j in range(1,10):
            tpl.append(i)
            tpl.append(j)
            tpl = tuple(tpl)
            lst.append(tpl)
            tpl = []
    for i in range(len(str)):
        lst_of_grid.append([lst[i],str[i]])
    return lst_of_grid
def lst_white(lst):
    for i in lst:
        for j in range(len(i)):
            i[j] = " "
    return lst
lst_white = lst_white(generate_field())
#################################################
class Game:
    def __init__(self):
        self.fields = [convert_list(generate_field()),convert_list(generate_field())]
        self.players = [Player('player1'), Player('player2')]
        self.current_player = 0
        self.white_fild = [convert_list(lst_white),convert_list(lst_white)]
    @property
    def increse_plaer(self):
        self.current_player  =  1 - ((self.current_player + 1) % 2)
        return self.current_player
    def read_position(self):
        return Player.read_position()
    def field_with_ships(self):
        n = Player.read_position
        for i in self.fields[self.current_player]:
            if i[0] == n:
                i[1] = 'X'
        return Field.schout_at(n)
    def field_without_ships(self):
        for i in self.white_fild[self.current_player+1]:
            if i[0] == Player.read_position:
                i[1] = 'X'
############################################
def game_over(self,fild):
    for i in fild :
        if i[1] == '*':
            return False
        else:
            return True
def scren(fild):
    str = ''
    n = 0
    for i in fild :
        str+= i[1]
        if n == 10:
            str += '/n'
    return str