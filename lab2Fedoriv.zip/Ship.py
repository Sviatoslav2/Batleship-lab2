import Player
import Game
import string
lst_alfabet = [i for i in string.ascii_uppercase]
class Ship:
    def __init__(self, bow, horizontal, length, hit):
        self.bow = bow
        self.horizontal = horizontal
        self.length = length
        self.hit = hit
    def  shoot_at(self,tupl):
        lst_of_ship_line = []
        if self.horizontal:
            lst_of_ship_cord = [[self.bow[0],self.bow[1]+i] for i in range(1,self.length[1]+1)]
        else:
            lst_of_ship_cord = [[self.bow[0]+i,self.bow[1]] for i in range(1, self.length[1]+1)]
        lst_of_ship = [(lst_alfabet[i[0]],i[1])for i in lst_of_ship_cord]
        for i in lst_of_ship :
            if tupl ==  i :
                lst_of_ship_line.append(True)
            else :
                lst_of_ship_line.append(False)
        return lst_of_ship_line
