
class Filld ():
    def __init__(self, initial):
        self.__schips = self.fields[self.current_player]
    def schout_at(self,tuple):
        n = 0
        for i in self.__schips:
            if i[0] == tuple and( i[1] == '*'):
                n += 1
                return n








